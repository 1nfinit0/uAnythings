import { c as createComponent } from './astro-component_DQ15uMiM.mjs';
import { o as renderComponent, k as renderTemplate, m as maybeRenderHead } from './entrypoint_Mk682Qki.mjs';
import { $ as $$Layout, r as renderScript, a as $$Logo, b as $$Nav, c as $$Ubicanos } from './Ubicanos_03xIoeQC.mjs';

const $$RegistroPlatillo = createComponent(async ($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "WallpaWawqi" }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<header class="w-full flex flex-col"> <div class="w-full flex items-center justify-between bg-primary py-4 px-4 md:px-24"> ${renderComponent($$result2, "Logo", $$Logo, {})} ${renderComponent($$result2, "Nav", $$Nav, {})} </div> </header> <main class="w-full flex flex-col items-center justify-center py-12 px-4 md:px-24"> <form id="platilloForm" class="w-full max-w-md bg-white rounded-lg shadow-lg p-8 flex flex-col gap-6"> <h2 class="text-2xl font-bold text-gray-800 mb-6">Registrar Platillo</h2> <label class="block"> <span class="text-gray-700 font-semibold mb-2 block">Nombre:</span> <input type="text" name="name" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"> </label> <label class="block"> <span class="text-gray-700 font-semibold mb-2 block">Precio:</span> <input type="text" name="price" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"> </label> <label class="block"> <span class="text-gray-700 font-semibold mb-2 block">Categoría:</span> <input type="text" name="category" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"> </label> <label class="block"> <span class="text-gray-700 font-semibold mb-2 block">Descripción:</span> <textarea name="description" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary resize-none h-28"></textarea> </label> <label class="block"> <span class="text-gray-700 font-semibold mb-2 block">URL de imagen:</span> <input type="url" name="img" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"> </label> <button type="submit" class="w-full bg-text-feature hover:bg-text-secondary font-bold py-2 px-4 rounded-lg transition duration-200 text-primary">Guardar</button> </form> <div id="resultado" class="mt-6 text-center text-sm"></div> </main> <footer> ${renderComponent($$result2, "Ubicanos", $$Ubicanos, {})} </footer> ` })} ${renderScript($$result, "/home/tobi/Desktop/repos/wallpaWawqi/src/pages/RegistroPlatillo.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/tobi/Desktop/repos/wallpaWawqi/src/pages/RegistroPlatillo.astro", void 0);

const $$file = "/home/tobi/Desktop/repos/wallpaWawqi/src/pages/RegistroPlatillo.astro";
const $$url = "/RegistroPlatillo";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$RegistroPlatillo,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
