import { p as createRenderInstruction, h as addAttribute, q as renderHead, v as renderSlot, k as renderTemplate, m as maybeRenderHead } from './entrypoint_Mk682Qki.mjs';
import { c as createComponent } from './astro-component_DQ15uMiM.mjs';

async function renderScript(result, id) {
  const inlined = result.inlinedScripts.get(id);
  let content = "";
  if (inlined != null) {
    if (inlined) {
      content = `<script type="module">${inlined}</script>`;
    }
  } else {
    const resolved = await result.resolve(id);
    content = `<script type="module" src="${result.userAssetsBase ? (result.base === "/" ? "" : result.base) + result.userAssetsBase : ""}${resolved}"></script>`;
  }
  return createRenderInstruction({ type: "script", id, content });
}

const $$Layout = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$Layout;
  const {
    title
  } = Astro2.props;
  return renderTemplate`<html lang="en"> <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width"><link rel="icon" type="image/svg+xml" href="/favicon.svg"><link rel="icon" href="/favicon.ico"><meta name="generator"${addAttribute(Astro2.generator, "content")}><title>${title}</title>${renderHead()}</head> <body> ${renderSlot($$result, $$slots["default"])} </body></html>`;
}, "/home/tobi/Desktop/repos/wallpaWawqi/src/layouts/Layout.astro", void 0);

const $$Logo = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div class="w-fit flex items-center justify-center flex-nowrap"> <div class="w-16 h-auto mx-4 "> <img src="/logo.jpeg" alt="Logo" class="w-full h-auto object-cover rounded-full"> </div> <p class="text-2xl font-bold text-text-feature">
WallpaWawqi
</p> </div>`;
}, "/home/tobi/Desktop/repos/wallpaWawqi/src/components/Logo.astro", void 0);

const $$Nav = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<nav class="w-fit flex items-center justify-end"> <ul class="flex space-x-8"> <li><a href="/" class="text-text-secondary hover:text-text-feature text-lg">Home</a></li> <li><a href="/about" class="text-text-secondary hover:text-text-feature text-lg">About</a></li> <li><a href="/contact" class="text-text-secondary hover:text-text-feature text-lg">Contact</a></li> <li><a href="/cart" class="text-text-secondary hover:text-text-feature text-lg">🛒</a></li> </ul> </nav>`;
}, "/home/tobi/Desktop/repos/wallpaWawqi/src/components/Nav.astro", void 0);

const $$Ubicanos = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div class="relative flex flex-col items-center justify-center bg-linear-to-br from-gray-900 via-gray-800 to-black text-white px-4 py-12"> <div class="max-w-2xl text-center space-y-8"> <div> <h3 class="text-6xl font-bold mb-4 bg-linear-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
Ubícanos
</h3> <div class="w-24 h-1 bg-linear-to-r from-blue-400 to-purple-500 mx-auto mb-8"></div> </div> <p class="text-xl text-gray-300 leading-relaxed">
Encuéntranos en el corazón comercial de Villa El Salvador, a las afueras de la Universidad UTP.
</p> <div class="pt-8"> <a href="#mapa" class="inline-block bg-linear-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105">
Ver mapa
</a> </div> </div> </div>`;
}, "/home/tobi/Desktop/repos/wallpaWawqi/src/components/Ubicanos.astro", void 0);

export { $$Layout as $, $$Logo as a, $$Nav as b, $$Ubicanos as c, renderScript as r };
