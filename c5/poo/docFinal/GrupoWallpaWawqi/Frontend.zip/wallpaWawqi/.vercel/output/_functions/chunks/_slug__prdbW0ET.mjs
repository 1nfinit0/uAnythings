import { c as createComponent } from './astro-component_DQ15uMiM.mjs';
import { m as maybeRenderHead, k as renderTemplate } from './entrypoint_Mk682Qki.mjs';

async function getStaticPaths() {
  const response = await fetch("https://wallpawawqisql-production.up.railway.app/productos");
  const productos = await response.json();
  return productos.map((producto) => ({
    params: { slug: producto.id.toString() },
    props: { producto }
  }));
}
const $$slug = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$props, $$slots);
  Astro2.self = $$slug;
  const { producto } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<h1>${producto.name}</h1> <p>${producto.description}</p>`;
}, "/home/tobi/Desktop/repos/wallpaWawqi/src/pages/[slug].astro", void 0);

const $$file = "/home/tobi/Desktop/repos/wallpaWawqi/src/pages/[slug].astro";
const $$url = "/[slug]";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$slug,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
