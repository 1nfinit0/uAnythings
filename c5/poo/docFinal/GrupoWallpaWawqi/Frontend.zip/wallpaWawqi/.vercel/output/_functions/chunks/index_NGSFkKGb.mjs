import { c as createComponent } from './astro-component_DQ15uMiM.mjs';
import { m as maybeRenderHead, k as renderTemplate, o as renderComponent } from './entrypoint_Mk682Qki.mjs';
import { r as renderScript, $ as $$Layout, a as $$Logo, b as $$Nav, c as $$Ubicanos } from './Ubicanos_03xIoeQC.mjs';

const $$Hero = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div class="w-full h-120 relative overflow-hidden flex items-center justify-center"> <img class="w-full h-full object-cover absolute inset-0 brightness-50" src="/imgs/hero.webp" alt="Hero Image"> <div class="w-full max-w-6xl flex items-center  py-16 px-8 md:px-12 z-90 relative "> <div class="w-full md:w-1/2"> <h1 class="text-5xl md:text-6xl mb-4 text-primary"><i>Pollo a la Brasa</i></h1> <p class="text-lg mb-8 text-primary">Auténtico Sabor Peruano</p> <div class="flex space-x-4 justify-center md:justify-start"> <a href="#explore" class="bg-text-feature text-white px-6 py-3 rounded-lg hover:bg-text-feature-hover transition duration-300">Ordenar Ahora</a> <a href="#explore" class="bg-white/30 backdrop-blur-sm border text-primary px-6 py-3 rounded-lg hover:bg-text-feature-dark transition duration-300">Ver Menú</a> </div> </div> <div class="w-1/2 max-w-md hidden md:block"> <img class="w-full h-auto rounded-full shadow-lg filter brightness-75" src="/logo.jpeg" alt="Hero Food Image"> </div> </div> </div>`;
}, "/home/tobi/Desktop/repos/wallpaWawqi/src/components/Hero.astro", void 0);

const $$MenuClient = createComponent(async ($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div id="menu-container" class="w-full flex flex-wrap gap-4 justify-center py-8"> <p class="text-center text-text">Cargando productos...</p> </div> ${renderScript($$result, "/home/tobi/Desktop/repos/wallpaWawqi/src/components/MenuClient.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/tobi/Desktop/repos/wallpaWawqi/src/components/MenuClient.astro", void 0);

const prerender = false;
const $$Index = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "Layout", $$Layout, { "title": "WallpaWawqi" }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<header class="w-full flex flex-col"> <div class="w-full flex items-center justify-between bg-primary py-4 px-4 md:px-24"> ${renderComponent($$result2, "Logo", $$Logo, {})} ${renderComponent($$result2, "Nav", $$Nav, {})} </div> <div class="w-full"> ${renderComponent($$result2, "Hero", $$Hero, {})} </div> </header> <main class="w-full flex flex-col items-center justify-center py-12 px-4 md:px-24"> <div class="w-full text-center"> <h2 class="text-text-feature text-3xl py-8">Productos Destacados</h2> <p class="text-text">Descubre nuestras especialdades.</p> </div> <section class="w-full max-w-6xl"> ${renderComponent($$result2, "MenuClient", $$MenuClient, {})} </section> </main> <footer> ${renderComponent($$result2, "Ubicanos", $$Ubicanos, {})} </footer> ` })}`;
}, "/home/tobi/Desktop/repos/wallpaWawqi/src/pages/index.astro", void 0);

const $$file = "/home/tobi/Desktop/repos/wallpaWawqi/src/pages/index.astro";
const $$url = "";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  prerender,
  url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
